<?php
$config['wordwrap'] = TRUE;
$config['protocol'] = 'mail';
$config['charset'] = 'iso-8859-1';
$config['mailtype'] = 'html';
$config['newline'] = "\r\n";
